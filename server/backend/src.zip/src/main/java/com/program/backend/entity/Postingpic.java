package com.program.backend.entity;

public class Postingpic {
    private String postingId;
    private String postingPic;

    public String getPostingId() {
        return postingId;
    }

    public void setPostingId(String postingId) {
        this.postingId = postingId;
    }

    public String getPostingPic() {
        return postingPic;
    }

    public void setPostingPic(String postingPic) {
        this.postingPic = postingPic;
    }
}
